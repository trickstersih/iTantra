---
license: cc-by-4.0
language:
- en
library_name: onnx-asr
base_model:
- nvidia/stt_en_conformer_ctc_small
tags:
- automatic-speech-recognition
- onnx
- nemo
pipeline_tag: automatic-speech-recognition
---

# nvidia-en-conformer-ctc-small-onnx

ASR model exported to ONNX for the
[onnx-asr](https://github.com/istupakov/onnx-asr) library and the
[ovos-stt-plugin-onnx-asr](https://github.com/OpenVoiceOS/ovos-stt-plugin-onnx-asr)
OpenVoiceOS STT plugin. Ships both fp32 and int8 weights.

Language: **English**. Converted from [nvidia/stt_en_conformer_ctc_small](https://huggingface.co/nvidia/stt_en_conformer_ctc_small).

```python
import onnx_asr
model = onnx_asr.load_model("OpenVoiceOS/nvidia-en-conformer-ctc-small-onnx")
print(model.recognize("audio.wav"))
```
